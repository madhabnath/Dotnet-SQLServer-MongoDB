﻿using System;
using System.Collections.Generic;

#nullable disable

namespace MyHangFireDemo.Helpers
{
    public partial class SQLBooks
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal? Price { get; set; }
        public string Category { get; set; }
        public string Author { get; set; }
        public int? NewStatus { get; set; }
        public string BookOrigin { get; set; }
    }
}
