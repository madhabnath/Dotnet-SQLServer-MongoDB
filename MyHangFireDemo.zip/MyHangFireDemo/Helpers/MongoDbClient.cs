﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace MyHangFireDemo.Helpers
{
    public interface IMongoDbClient
    {
        IMongoCollection<MongoBook> GetBooksCollection();
    }
    public class MongoDbClient : IMongoDbClient
    {
        private readonly IMongoCollection<MongoBook> _mongoBook;
        public MongoDbClient(IOptions<MongoBookStoreDbConfig> mongoBookstoreDbConfig)
        {
            var client = new MongoClient(mongoBookstoreDbConfig.Value.MongoConnectionString);
            var database = client.GetDatabase(mongoBookstoreDbConfig.Value.MongoDatabaseName);
            _mongoBook = database.GetCollection<MongoBook>(mongoBookstoreDbConfig.Value.MongoBooksCollectionName);
        }
        public IMongoCollection<MongoBook> GetBooksCollection()
        {
            return _mongoBook;
        }
    }
}
