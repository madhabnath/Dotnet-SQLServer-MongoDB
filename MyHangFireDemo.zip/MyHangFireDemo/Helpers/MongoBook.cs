﻿using MongoDB.Bson.Serialization.Attributes;

namespace MyHangFireDemo.Helpers
{
    public class MongoBook
    {
        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]

        public string Id { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public string Category { get; set; }
        public string Author { get; set; }
        public int NewStatus { get; set; }
    }
}
