﻿using static System.Reflection.Metadata.BlobBuilder;
using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MyHangFireDemo.Helpers
{
    public class SQLDataContext : DbContext
    {
        public SQLDataContext(DbContextOptions<SQLDataContext> options)
        : base(options)
        {
        }

        public virtual DbSet<SQLBooks> Books { get; set; }
    }
}
