﻿namespace MyHangFireDemo.Helpers
{
    public interface IMongoBookStoreDbConfig
    {
        string MongoBooksCollectionName { get; set; }
        string MongoConnectionString { get; set; }
        string MongoDatabaseName { get; set; }
    }
    public class MongoBookStoreDbConfig : IMongoBookStoreDbConfig
    {
        public string MongoConnectionString { get; set; }
        public string MongoDatabaseName { get; set; }
        public string MongoBooksCollectionName { get; set; }
    }
}
