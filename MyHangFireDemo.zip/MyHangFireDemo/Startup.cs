using Hangfire;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using MyHangFireDemo.Helpers;
using MyHangFireDemo.Services;
using MyHangFireDemo.Utilitities;
using MyHangFireDemo.Utility;

namespace MyHangFireDemo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "MyHangFireDemo", Version = "v1" });
            });

            // requires using Microsoft.Extensions.Options
            services.Configure<MongoBookStoreDbConfig>(
                Configuration.GetSection(nameof(MongoBookStoreDbConfig)));

            services.AddSingleton<IMongoBookStoreDbConfig>(sp =>
                sp.GetRequiredService<IOptions<MongoBookStoreDbConfig>>().Value);

            // Mongo Service Configuration
            services.AddScoped<IMongoDbClient, MongoDbClient>();

            // SQL Server Service Configuration
            services.AddDbContext<SQLDataContext>(Options => Options.UseSqlServer(Configuration.GetConnectionString("BookDBConnection")));
            
            // Hangfire Job Configuration - Start
            services.AddHangfire(x =>
            {
                x.UseSqlServerStorage(Configuration.GetConnectionString("HangfireDBConnection"));
            });
            services.AddHangfireServer();
            //services.AddHangfireServer(options => options.WorkerCount = 30);
            //services.AddHangfireServer(options => options.WorkerCount = 50);
            services.AddScoped<IJobService, JobService>();
            // Hangfire Job Service Configuration

            // XML Utility Configuration
            services.AddScoped<IXMLUtility, XMLUtility>();

            // SQL Book Utility Configuration
            services.AddScoped<ISQLBookUtility, SQLBookUtility>();

            // Mongo Book Utility Configuration
            services.AddScoped<IMongoBookUtility, MongoBookUtility>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "MyHangFireDemo v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseHangfireDashboard();
        }
    }
}
