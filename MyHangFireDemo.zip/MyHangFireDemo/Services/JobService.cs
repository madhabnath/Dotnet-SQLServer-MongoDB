﻿using MongoDB.Driver;
using MyHangFireDemo.Helpers;
using MyHangFireDemo.Models;
using MyHangFireDemo.Utilitities;
using MyHangFireDemo.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyHangFireDemo.Services
{
    public class JobService : IJobService
    {
        private readonly IXMLUtility _XMLUtility;
        private readonly ISQLBookUtility _SQLBookUtility;
        private readonly IMongoBookUtility _MongoBookUtility;
        private readonly SQLBooksModel _bookModel = new SQLBooksModel();

        public JobService(IXMLUtility XMLUtility, ISQLBookUtility SQLBookUtility, IMongoBookUtility MongoBookUtility)
        {
            _XMLUtility = XMLUtility;
            _SQLBookUtility = SQLBookUtility;
            _MongoBookUtility = MongoBookUtility;
        }        

        // Hangfire Job Implementation - Started
        public async Task CreateGetNewBookJob()
        {
            // List all the new Book available on SQL Server
            var newBook = await _SQLBookUtility.GetNewBookAsync();
            foreach (var insertBook in newBook)
            {
                // Insert the new Book from SQL Server to Mongo
                _MongoBookUtility.AddNewBookInMongo(new MongoBook
                {
                    Name = insertBook.Name,
                    Price = (double)insertBook.Price,
                    Category = insertBook.Category,
                    Author = insertBook.Author,
                    NewStatus = (int)insertBook.NewStatus
                });

                // Update the Book as NewStatus = 0 in SQL Server, as this Book got processed
                await _SQLBookUtility.UpdateNewBookAsync(insertBook.Id, _bookModel);
            }
        }
        public void CreateNewBookReportJob()
        {
            // Get all the new Book, and Update NewStatus = 0 in Mongo
            List<MongoBook> reportedBooks = _MongoBookUtility.GetNewBookFromMongo();
            if (reportedBooks.Any())
            {
                _XMLUtility.GenXML(reportedBooks);
            }
        }
        public void FireAndForgetJob()
        {
            Console.WriteLine("Hello from a Fire and Forget job!");
        }
        public void ReccuringJob()
        {
            Console.WriteLine("Hello from a Scheduled job!");
        }
        public void DelayedJob()
        {
            Console.WriteLine("Hello from a Delayed job!");
        }
        public void ContinuationJob()
        {
            Console.WriteLine("Hello from a Continuation job!");
        }
        // Hangfire Job Implementation - End
    }
}
