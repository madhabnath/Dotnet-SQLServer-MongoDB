﻿using MongoDB.Driver;
using MyHangFireDemo.Helpers;
using System.Collections.Generic;

namespace MyHangFireDemo.Utilitities
{
    public interface IMongoBookUtility
    {
        List<MongoBook> GetBooksFromMongo();
        MongoBook GetBookFromMongo(string id);
        List<MongoBook> GetNewBookFromMongo();
        MongoBook AddBookInMongo(MongoBook book);
        void AddNewBookInMongo(MongoBook book);
        void DeleteBookFromMongo(string id);
        MongoBook UpdateBookInMongo(MongoBook book);
    }
    public class MongoBookUtility : IMongoBookUtility
    {
        private readonly IMongoCollection<MongoBook> _books;
        public MongoBookUtility(IMongoDbClient mongoDbClient)
        {
            _books = mongoDbClient.GetBooksCollection();
        }

        // Mongo DB Services Implementation - Started
        public MongoBook AddBookInMongo(MongoBook book)
        {
            _books.InsertOne(book);
            return book;
        }
        public void AddNewBookInMongo(MongoBook book)
        {
            _books.InsertOne(book);
        }
        public void DeleteBookFromMongo(string id)
        {
            _books.DeleteOne(book => book.Id == id);
        }
        public MongoBook GetBookFromMongo(string id)
        {
            return _books.Find(book => book.Id == id).First();
        }
        public List<MongoBook> GetBooksFromMongo()
        {
            /*return new List<Book>()
            {
                new Book
                {
                    Name = "Glimpse of God",
                    Price = 16.99,
                    Category = "Category 1",
                    Author = "R P Shah",
                    NewStatus = 1
                }
            };*/

            return _books.Find(book => true).ToList();
        }
        public List<MongoBook> GetNewBookFromMongo()
        {
            List<MongoBook> newBooks = new List<MongoBook>();
            newBooks = _books.Find(book => book.NewStatus == 1).ToList();

            UpdateDefinition<MongoBook> updateDefinition = Builders<MongoBook>.Update.Set(x => x.NewStatus, 0);
            _books.UpdateMany(x => x.NewStatus == 1, updateDefinition); // replaces all matches

            return newBooks;
        }
        public MongoBook UpdateBookInMongo(MongoBook book)
        {
            GetBookFromMongo(book.Id);
            _books.ReplaceOne(b => b.Id == book.Id, book);
            return book;
        }
        // Mongo DB Services Implementation - End
    }
}
